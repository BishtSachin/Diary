// ============================================================================
// qlik-capability.js — Qlik Sense Enterprise (on-prem) embedding via the
// Capability API. Renders NATIVE Qlik objects into your own <div>s (no iframe)
// and supports native data export.
//
// Flow (called from QlikDashboard.razor):
//   1. render(cfg): plant the QPS session cookie silently with cfg.redeemUrl
//      (no redirect), load require.js from the Qlik host, qlik.openApp(),
//      then app.visualization.get(id).show(div) for each object.
//   2. exportObject(id, format): native Qlik export -> download link.
//
// cfg = { mode, host, prefix, redeemUrl, appId, objectIds[], mockUrl }
// ============================================================================

let _app = null;
let _dotnet = null;
const _vis = {};          // objectId -> visualization handle (for export)

// ── session: redeem the QPS ticket without navigating away ──────────────────
function plantSession(redeemUrl) {
    return new Promise((resolve) => {
        if (!redeemUrl) { resolve(false); return; }
        // A background no-cors fetch hits the virtual proxy with ?qlikTicket=,
        // which sets the Qlik session cookie. No page redirect.
        // (Requires first-party cookies: host the app same-domain as Qlik, or a
        //  reverse proxy — otherwise browsers drop the third-party cookie.)
        fetch(redeemUrl, { credentials: "include", mode: "no-cors" })
            .then(() => resolve(true))
            .catch(() => resolve(false));
        // Safety timeout so a blocked request never hangs the render.
        setTimeout(() => resolve(true), 2500);
    });
}

function loadScript(src) {
    return new Promise((resolve, reject) => {
        const s = document.createElement("script");
        s.src = src; s.onload = resolve; s.onerror = () => reject(new Error("load failed: " + src));
        document.head.appendChild(s);
    });
}

function parseHost(host, prefix) {
    const u = new URL(host);
    return {
        host: u.hostname,
        port: u.port || (u.protocol === "https:" ? 443 : 80),
        prefix: "/" + (prefix ? prefix.replace(/^\/+|\/+$/g, "") + "/" : ""),
        isSecure: u.protocol === "https:"
    };
}

// ── dev mock dashboard, rendered natively (no iframe, no docker dependency) ──
function renderMockDashboard(grid) {
    const NS = "http://www.w3.org/2000/svg";
    const el = (t, a) => { const e = document.createElementNS(NS, t); for (const k in a) e.setAttribute(k, a[k]); return e; };

    const months = ["Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec","Jan","Feb","Mar"];
    const deposits = [7.1,7.3,7.6,7.5,7.9,8.2,8.4,8.7,9.0,9.3,9.6,10.1];
    const advances = [4.2,4.3,4.5,4.6,4.8,5.0,5.1,5.3,5.5,5.7,5.9,6.2];
    const mix = [{l:"Savings",v:38,c:"#54a020"},{l:"Current",v:17,c:"#3f8ecc"},{l:"Term",v:28,c:"#f6a623"},{l:"Advances",v:17,c:"#d0021b"}];
    const regions = [
        {n:"Mumbai",d:3.8,g:9.1,t:0.86},{n:"Delhi",d:3.1,g:7.4,t:0.79},{n:"Chennai",d:2.4,g:6.2,t:0.72},
        {n:"Kolkata",d:1.9,g:5.1,t:0.65},{n:"Lucknow",d:1.6,g:4.4,t:0.58}];

    grid.innerHTML = `
      <style>
        .qm-note{padding:6px 10px;background:#fff8e1;border:1px solid #ffe0a3;border-radius:4px;margin-bottom:10px;font-size:12px;color:#8a6d00;}
        .qm-cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;}
        .qm-card{background:#fff;border:1px solid #e5e5e5;border-radius:4px;padding:14px;box-shadow:0 1px 2px rgba(0,0,0,.04);}
        .qm-card h3{margin:0 0 10px;font-size:11px;font-weight:600;letter-spacing:.4px;color:#6a6a6a;text-transform:uppercase;}
        .qm-val{font-size:28px;font-weight:700;line-height:1;color:#404040;} .qm-sub{font-size:12px;color:#6a6a6a;margin-top:6px;}
        .qm-up{color:#54a020;} .qm-down{color:#d0021b;}
        .qm-span2{grid-column:span 2;}
        .qm-legend{display:flex;gap:14px;flex-wrap:wrap;margin-top:8px;font-size:12px;color:#6a6a6a;}
        .qm-legend .k{display:inline-flex;align-items:center;gap:6px;} .qm-sw{width:11px;height:11px;border-radius:2px;display:inline-block;}
        .qm-table{width:100%;border-collapse:collapse;font-size:13px;}
        .qm-table th,.qm-table td{text-align:left;padding:7px 8px;border-bottom:1px solid #e5e5e5;}
        .qm-table th{color:#6a6a6a;font-weight:600;font-size:11px;text-transform:uppercase;letter-spacing:.4px;}
        .qm-num{text-align:right;font-variant-numeric:tabular-nums;}
        .qm-bar{background:#eef6e7;border-radius:3px;height:8px;overflow:hidden;} .qm-bar>i{display:block;height:100%;background:#54a020;}
        .qm-svg{width:100%;height:220px;display:block;}
      </style>
      <div class="qm-note">DEV MOCK — Capability API needs a live Qlik host. Showing a native sample dashboard (no iframe).</div>
      <div class="qm-cards">
        <div class="qm-card"><h3>Total Business</h3><div class="qm-val">₹ 12.84 Cr</div><div class="qm-sub qm-up">▲ 8.2% vs LY</div></div>
        <div class="qm-card"><h3>CASA Ratio</h3><div class="qm-val">41.6%</div><div class="qm-sub qm-up">▲ 1.3 pts</div></div>
        <div class="qm-card"><h3>NPA %</h3><div class="qm-val">2.9%</div><div class="qm-sub qm-down">▲ 0.2 pts</div></div>
        <div class="qm-card"><h3>Open Requests</h3><div class="qm-val">1,742</div><div class="qm-sub">312 breaching SLA</div></div>
        <div class="qm-card qm-span2"><h3>Monthly Business Trend (₹ Cr)</h3><svg id="qm-line" class="qm-svg" viewBox="0 0 480 220" preserveAspectRatio="none"></svg>
          <div class="qm-legend"><span class="k"><span class="qm-sw" style="background:#54a020"></span>Deposits</span><span class="k"><span class="qm-sw" style="background:#3f8ecc"></span>Advances</span></div></div>
        <div class="qm-card qm-span2"><h3>Business Mix by Product</h3><svg id="qm-donut" class="qm-svg" viewBox="0 0 480 220"></svg>
          <div class="qm-legend">${mix.map(m=>`<span class="k"><span class="qm-sw" style="background:${m.c}"></span>${m.l}</span>`).join("")}</div></div>
        <div class="qm-card qm-span2"><h3>Region-wise Deposits (₹ Cr)</h3><svg id="qm-bar" class="qm-svg" viewBox="0 0 480 220"></svg></div>
        <div class="qm-card qm-span2"><h3>Top Regions — Performance</h3>
          <table class="qm-table"><thead><tr><th>Region</th><th>Deposits</th><th>Growth</th><th style="width:110px">Target</th></tr></thead>
          <tbody>${regions.map(r=>`<tr><td>${r.n}</td><td class="qm-num">₹ ${r.d.toFixed(1)} Cr</td><td class="qm-num" style="color:#54a020">▲ ${r.g}%</td><td><div class="qm-bar"><i style="width:${Math.round(r.t*100)}%"></i></div></td></tr>`).join("")}</tbody></table></div>
      </div>`;

    // line
    (function(){ const svg=grid.querySelector("#qm-line"),W=480,H=220,pad=28,max=Math.max(...deposits,...advances)*1.1;
        const x=i=>pad+i*(W-pad*2)/(months.length-1),y=v=>H-pad-(v/max)*(H-pad*2);
        for(let g=0;g<=4;g++){const yy=pad+g*(H-pad*2)/4;svg.appendChild(el("line",{x1:pad,y1:yy,x2:W-pad,y2:yy,stroke:"#eee"}));}
        const draw=(arr,c)=>{let d="";arr.forEach((v,i)=>d+=(i?"L":"M")+x(i)+" "+y(v)+" ");svg.appendChild(el("path",{d,fill:"none",stroke:c,"stroke-width":2.5}));arr.forEach((v,i)=>svg.appendChild(el("circle",{cx:x(i),cy:y(v),r:3,fill:c})));};
        draw(deposits,"#54a020");draw(advances,"#3f8ecc");
        months.forEach((m,i)=>{const t=el("text",{x:x(i),y:H-8,"font-size":9,fill:"#999","text-anchor":"middle"});t.textContent=m;svg.appendChild(t);});})();
    // donut
    (function(){ const svg=grid.querySelector("#qm-donut"),cx=240,cy=110,r=78,ir=44,total=mix.reduce((s,m)=>s+m.v,0);let a=-Math.PI/2;
        mix.forEach(m=>{const a2=a+m.v/total*Math.PI*2,p=(ang,rad)=>[cx+Math.cos(ang)*rad,cy+Math.sin(ang)*rad];
        const[x1,y1]=p(a,r),[x2,y2]=p(a2,r),[x3,y3]=p(a2,ir),[x4,y4]=p(a,ir),big=(a2-a)>Math.PI?1:0;
        svg.appendChild(el("path",{d:`M${x1} ${y1} A${r} ${r} 0 ${big} 1 ${x2} ${y2} L${x3} ${y3} A${ir} ${ir} 0 ${big} 0 ${x4} ${y4} Z`,fill:m.c}));a=a2;});
        const t=el("text",{x:cx,y:cy+5,"font-size":18,"font-weight":700,fill:"#404040","text-anchor":"middle"});t.textContent="100%";svg.appendChild(t);})();
    // bar
    (function(){ const svg=grid.querySelector("#qm-bar"),W=480,H=220,pad=30,max=Math.max(...regions.map(r=>r.d))*1.15,bw=(W-pad*2)/regions.length*0.55;
        regions.forEach((rg,i)=>{const cx=pad+i*(W-pad*2)/regions.length+(W-pad*2)/regions.length/2,h=(rg.d/max)*(H-pad*2),yy=H-pad-h;
        svg.appendChild(el("rect",{x:cx-bw/2,y:yy,width:bw,height:h,rx:2,fill:"#54a020"}));
        const v=el("text",{x:cx,y:yy-5,"font-size":10,fill:"#404040","text-anchor":"middle"});v.textContent=rg.d;svg.appendChild(v);
        const t=el("text",{x:cx,y:H-10,"font-size":9,fill:"#999","text-anchor":"middle"});t.textContent=rg.n;svg.appendChild(t);});})();
}

export async function render(cfg, dotnetRef) {
    _dotnet = dotnetRef;
    const grid = document.getElementById("qlik-object-grid");
    if (!grid) return { ok: false, error: "grid-missing" };
    grid.innerHTML = "";

    // ── Dev mock preview (no live Qlik engine to speak Capability to) ───────
    if (cfg.mode && cfg.mode.toLowerCase() === "mock") {
        // No iframe: draw the mock dashboard directly into the page DOM.
        grid.style.display = "block";
        grid.style.gridTemplateColumns = "none";
        grid.style.height = "auto";
        grid.style.overflow = "visible";
        renderMockDashboard(grid);
        return { ok: true, mock: true };
    }

    // ── Live Qlik: ticket session → require.js → openApp → render objects ───
    try {
        await plantSession(cfg.redeemUrl);

        const base = cfg.host.replace(/\/+$/, "") + (cfg.prefix ? "/" + cfg.prefix.replace(/^\/+|\/+$/g, "") : "");
        // Capability API stylesheet + require.js from the Qlik host.
        const css = document.createElement("link");
        css.rel = "stylesheet";
        css.href = base + "/resources/autogenerated/qlik-styles.css";
        document.head.appendChild(css);

        window.require = window.require || undefined;
        await loadScript(base + "/resources/assets/external/requirejs/require.js");
        window.requirejs.config({ baseUrl: base + "/resources", webIntegrationApi: false });

        const qlik = await new Promise((resolve, reject) =>
            window.requirejs(["js/qlik"], resolve, reject));

        qlik.setOnError((err) => {
            console.error("[qlik] engine error", err);
            if (_dotnet) _dotnet.invokeMethodAsync("OnQlikError", (err && err.message) || "Qlik engine error");
        });

        const conn = parseHost(cfg.host, cfg.prefix);
        _app = qlik.openApp(cfg.appId, conn);

        const ids = cfg.objectIds && cfg.objectIds.length ? cfg.objectIds : [];
        if (!ids.length) {
            const msg = document.createElement("div");
            msg.style.cssText = "padding:12px;color:#666;font-size:13px;";
            msg.textContent = "No object IDs configured (Qlik:ObjectIds). Add the sheet's visualization GUIDs to render them here.";
            grid.appendChild(msg);
        }

        for (const id of ids) {
            const cell = document.createElement("div");
            cell.className = "qlik-cell";
            cell.style.cssText = "position:relative;min-height:320px;background:#fff;border:1px solid #e5e5e5;border-radius:4px;overflow:hidden;";
            const holder = document.createElement("div");
            holder.id = "qv-" + id;
            holder.style.cssText = "width:100%;height:100%;min-height:320px;";
            cell.appendChild(holder);
            grid.appendChild(cell);

            // Visualization API: renders the native object AND supports exportData.
            _app.visualization.get(id).then((vis) => {
                _vis[id] = vis;
                vis.show(holder.id);
                if (_dotnet) _dotnet.invokeMethodAsync("OnObjectRendered", id);
            }).catch((e) => {
                holder.innerHTML = '<div style="padding:12px;color:#c0392b;font-size:12px;">Failed to load object ' + id + ': ' + (e && e.message || e) + '</div>';
            });
        }
        return { ok: true, objects: ids.length };
    } catch (e) {
        console.error("[qlik] render failed", e);
        if (_dotnet) _dotnet.invokeMethodAsync("OnQlikError", (e && e.message) || String(e));
        return { ok: false, error: (e && e.message) || String(e) };
    }
}

// ── native export (Excel / CSV) for a rendered object ───────────────────────
export async function exportObject(objectId, format) {
    const vis = _vis[objectId];
    if (!vis) { console.warn("[qlik] no visualization for", objectId); return { ok: false }; }
    const fmt = (format || "OOXML").toUpperCase();     // OOXML = xlsx, CSV_T = csv
    try {
        const url = await vis.exportData({ format: fmt, state: "A" });
        // Trigger the browser download of the Qlik-generated file.
        const a = document.createElement("a");
        a.href = url; a.download = "";
        document.body.appendChild(a); a.click(); a.remove();
        return { ok: true, url };
    } catch (e) {
        console.error("[qlik] export failed", e);
        return { ok: false, error: (e && e.message) || String(e) };
    }
}

// ── print the rendered dashboard to PDF (browser "Save as PDF") ─────────────
export function printPdf() {
    try {
        window.focus();
        window.print();
        return { ok: true };
    } catch (e) {
        console.error("[qlik] print failed", e);
        return { ok: false, error: (e && e.message) || String(e) };
    }
}

export function dispose() {
    try {
        if (_app && _app.close) _app.close();
    } catch { /* ignore */ }
    _app = null;
    for (const k in _vis) delete _vis[k];
    const grid = document.getElementById("qlik-object-grid");
    if (grid) grid.innerHTML = "";
}

export default { render, exportObject, dispose };
