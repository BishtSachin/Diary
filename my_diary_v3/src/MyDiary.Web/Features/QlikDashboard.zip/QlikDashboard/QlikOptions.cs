namespace MyDiary.Web.Features.QlikDashboard;

/// <summary>
/// Configuration for embedding Qlik Sense Enterprise (on-prem) content into the
/// portal via the Capability API with QPS ticket authentication.
///
/// Bound from the "Qlik" configuration section. In production the certificate
/// path/password and host live in the encrypted config / secret store.
/// </summary>
public sealed class QlikOptions
{
    /// <summary>"Capability" = live Qlik via ticket + Capability API (no iframe);
    /// "Mock" = local docker stand-in preview (dev only).</summary>
    public string Mode { get; set; } = "Mock";

    public string Title { get; set; } = "Qlik Dashboard";

    /// <summary>Qlik proxy host, scheme + host(+port) only, e.g. https://qlik.ubi.local</summary>
    public string Host { get; set; } = "";

    /// <summary>Virtual proxy prefix configured in the QMC (blank = default proxy).</summary>
    public string VirtualProxyPrefix { get; set; } = "";

    /// <summary>QPS ticket API host:port (defaults to {Host} on 4243 if blank).</summary>
    public string QpsUri { get; set; } = "";

    /// <summary>User directory Qlik expects for the ticket (e.g. UBI / DOMAIN).</summary>
    public string UserDirectory { get; set; } = "UBI";

    /// <summary>App GUID to open.</summary>
    public string AppId { get; set; } = "";

    /// <summary>Sheet id (for reference / "open in Qlik" deep link).</summary>
    public string SheetId { get; set; } = "";

    /// <summary>Object/visualization GUIDs to render into the page grid (a "sheet"
    /// is rendered as its list of objects). If empty, the whole sheet's objects
    /// are discovered client-side via the Capability API.</summary>
    public List<string> ObjectIds { get; set; } = new();

    /// <summary>Client certificate (PFX exported from the QMC) used for the mutual-TLS
    /// call to the QPS ticket endpoint.</summary>
    public string ClientCertPath { get; set; } = "";
    public string ClientCertPassword { get; set; } = "";

    /// <summary>Skip server-cert validation on the QPS call (dev only — Qlik uses a
    /// self-signed cert out of the box). MUST be false in production.</summary>
    public bool AllowInvalidServerCert { get; set; } = false;

    public bool IsMock => string.Equals(Mode, "Mock", StringComparison.OrdinalIgnoreCase);
}
