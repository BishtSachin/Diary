using ApexCharts;
using Hangfire;
using Hangfire.Oracle.Core;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Server;
using MudBlazor.Services;
using MyDiary.Core.Abstractions;
using MyDiary.Data.Oracle;
using MyDiary.Data.SqlServer;
using MyDiary.Web.Auth;
using MyDiary.Web.Components;
using MyDiary.Web.Core.Extensions;
using MyDiary.Web.Core.Services.Storage;
using MyDiary.Web.Data;
using MyDiary.Web.Extensions;
using MyDiary.Web.Features.Focus360.Models;
using MyDiary.Web.Features.Focus360.Services;
using MyDiary.Web.Features.Shared.Models;
using MyDiary.Web.Services;
using RequestPortal.Core;
using RequestPortal.Data;
using Serilog;

// ── Bootstrap Serilog ─────────────────────────────────────────────────────────
Log.Logger = new LoggerConfiguration()
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .WriteTo.File("Logs/mydiary-.log", rollingInterval: RollingInterval.Day)
    .CreateBootstrapLogger();

try
{
    Log.Information("Starting My Diary V3");

    var builder = WebApplication.CreateBuilder(args);

    // ── Decrypt connection strings (AES-256-GCM) and inject plain values ───
    var plainConn = MyDiary.Data.Extensions.ConnectionStringDecryptor.DecryptAll(builder.Configuration);
    builder.Configuration.AddInMemoryCollection(
        plainConn.Select(kv => new KeyValuePair<string, string?>($"ConnectionStrings:{kv.Key}", kv.Value)));

    // ── Serilog ────────────────────────────────────────────────────────────
    builder.Host.UseSerilog((ctx, lc) => lc
        .ReadFrom.Configuration(ctx.Configuration)
        .Enrich.FromLogContext()
        .WriteTo.Console()
        .WriteTo.File("Logs/mydiary-.log", rollingInterval: RollingInterval.Day));

    // ── SignalR + Razor components (Blazor Server) ─────────────────────────
    builder.Services.AddSignalR().AddJsonProtocol(o => o.PayloadSerializerOptions.PropertyNamingPolicy = null);

    // ── Web API controllers (server-to-server integration endpoints) ───────
    builder.Services.AddControllers();

    builder.Services.AddRazorComponents()
        .AddInteractiveServerComponents()
        .AddHubOptions(o =>
        {
            o.MaximumReceiveMessageSize = 1024 * 1024;
            o.KeepAliveInterval         = TimeSpan.FromSeconds(15);
            o.ClientTimeoutInterval     = TimeSpan.FromSeconds(120);
            o.HandshakeTimeout          = TimeSpan.FromSeconds(30);
        });

    // ── UI libraries ────────────────────────────────────────────────────────
    builder.Services.AddMudServices();
    builder.Services.AddApexCharts();

    // ── Project B feature services (reflection auto-registration) ──────────
    builder.Services.AddApplicationServices();

    // ── Data providers (Project B raw ADO.NET providers, point at docker DBs) ─
    builder.Services.AddSingleton<OracleDbProvider>();
    builder.Services.AddSingleton<SqlDbProvider>();

    // ── Project C Dapper repositories (Oracle rp-oracle / SQL Server gap) ──
    builder.Services.AddScoped<ISessionRepository,        SessionRepository>();
    builder.Services.AddScoped<IUserRepository,           UserRepository>();
    builder.Services.AddScoped<IRbacRepository,           RbacRepository>();
    builder.Services.AddScoped<INotificationRepository,   NotificationRepository>();

    // ── Project A Request Portal (Core + Data, unchanged query logic vs RP_* tables) ─
    builder.Services.AddRequestPortalCore();
    builder.Services.AddRequestPortalData();
    builder.Services.AddScoped<RequestPortal.Core.Abstractions.ICurrentUser,
                               RequestPortal.Web.Auth.CurrentUserService>();
    builder.Services.AddScoped<RequestPortal.Core.Abstractions.IUserDirectory,
                               RequestPortal.Web.Auth.UserDirectory>();
    builder.Services.AddScoped<RequestPortal.Web.Services.ModuleContext>();
    builder.Services.AddSingleton<RequestPortal.Web.Hubs.NotificationStream>();
    // Bridge A's email/SMS sender interfaces to C's unified MailKit senders
    builder.Services.AddScoped<RequestPortal.Core.Services.IEmailSender,
                               MyDiary.Web.RequestPortal.RequestPortalEmailSenderAdapter>();
    builder.Services.AddScoped<RequestPortal.Core.Services.ISmsSender,
                               MyDiary.Web.RequestPortal.RequestPortalSmsSenderAdapter>();
    builder.Services.AddScoped<RequestPortal.Core.Abstractions.INotificationPublisher,
                               MyDiary.Web.RequestPortal.NoOpNotificationPublisher>();
    builder.Services.AddScoped<RequestPortal.Core.Abstractions.IBroadcastDirectory,
                               RequestPortal.Data.Repositories.SqlBroadcastDirectory>();
    // Attachments persist to the DB (RP_ATTACHMENT_BLOB) rather than the filesystem.
    builder.Services.AddScoped<RequestPortal.Core.Services.IAttachmentStore,
                               RequestPortal.Data.Repositories.DbAttachmentStore>();
    // In-memory page metadata (avoids dragging Oracle PageInfo dependency)
    builder.Services.AddScoped<RequestPortal.Web.Features.PageInfo.Services.IPageInfoService,
                               RequestPortal.Web.Features.PageInfo.Services.DemoPageInfoService>();

    // ── HTTP clients ────────────────────────────────────────────────────────
    builder.Services.AddHttpClient<UserApiClient>();
    builder.Services.AddHttpClient("CryptoService", c => c.Timeout = TimeSpan.FromSeconds(10));
    builder.Services.AddHttpClient();

    // ── Encryption (Project B — CryptoService delegate) ────────────────────
    builder.Services.AddSingleton<IEncryptionService, EncryptionService>();
    builder.Services.AddScoped<AuthApiService>();

    // ── Qlik Sense embedding (Capability API + QPS ticket) ────────────────
    builder.Services.Configure<MyDiary.Web.Features.QlikDashboard.QlikOptions>(builder.Configuration.GetSection("Qlik"));
    builder.Services.AddScoped<MyDiary.Web.Features.QlikDashboard.IQlikTicketService,
                               MyDiary.Web.Features.QlikDashboard.QlikTicketService>();

    // ── Email / SMS (MailKit, migrated from Project A) ─────────────────────
    builder.Services.Configure<MyDiary.Web.Notify.SmtpOptions>(builder.Configuration.GetSection("Smtp"));
    builder.Services.AddScoped<IEmailSender, MyDiary.Web.Notify.SmtpEmailSender>();
    builder.Services.AddScoped<ISmsSender,   MyDiary.Web.Notify.NoOpSmsSender>();

    // ── Blazor circuit options ───────────────────────────────────────────────
    builder.Services.Configure<CircuitOptions>(o =>
    {
        o.DetailedErrors                       = builder.Environment.IsDevelopment();
        o.DisconnectedCircuitRetentionPeriod   = TimeSpan.FromMinutes(10);
        o.DisconnectedCircuitMaxRetained       = 1000;
        o.JSInteropDefaultCallTimeout          = TimeSpan.FromSeconds(60);
    });

    // ── Authorization (unified policies A + B) ──────────────────────────────
    builder.Services.AddAuthorization(MyDiary.Web.Auth.AuthorizationPolicies.AddMyDiaryAuthorization);

    // ── Authentication (Project B form login + session storage, RBAC-enriched) ─
    builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
        .AddCookie(o =>
        {
            o.LoginPath          = "/login";
            o.ExpireTimeSpan     = TimeSpan.FromHours(24);
            o.SlidingExpiration  = true;
            o.Cookie.HttpOnly    = true;
            o.Cookie.SecurePolicy = CookieSecurePolicy.Always;
            o.Cookie.SameSite    = SameSiteMode.Strict;
        })
        // Server-to-server API key scheme (UCCRMC etc.) — used by /api/* controllers
        .AddScheme<Microsoft.AspNetCore.Authentication.AuthenticationSchemeOptions,
                   MyDiary.Web.Auth.ApiKeyAuthenticationHandler>(
            MyDiary.Web.Auth.ApiKeyAuthenticationHandler.SchemeName, null);

    builder.Services.AddCascadingAuthenticationState();
    builder.Services.AddDataProtection();

    builder.Services.AddScoped<CustomAuthenticationStateProvider>();
    builder.Services.AddScoped<AuthenticationStateProvider>(sp =>
        sp.GetRequiredService<CustomAuthenticationStateProvider>());
    builder.Services.AddScoped<ICurrentUser, CurrentUser>();

    // SSO + session circuit handler (Project B)
    builder.Services.AddScoped<MyDiary.Web.Core.Services.Authentication.SSOService>();

    // Session storage: plain (load testing) or AES-encrypted (default)
    if (builder.Configuration.GetValue<bool>("DevSettings:LoadTestingMode"))
        builder.Services.AddScoped<ISessionStorageService, PlainSessionStorageService>();
    else
        builder.Services.AddScoped<ISessionStorageService, ProtectedSessionStorageService>();

    builder.Services.AddHttpContextAccessor();

    // DevSettings singleton (Project B)
    var devSettings = builder.Configuration.GetSection("DevSettings").Get<DevSettings>();
    builder.Services.AddSingleton(devSettings ?? new DevSettings());

    // ── Shared state services (Project B) ──────────────────────────────────
    builder.Services.AddScoped<ReportStateService>();
    builder.Services.AddScoped<NavState>();
    builder.Services.AddScoped<MyDiary.Web.Services.AppModuleNav>();

    // ── Concrete feature services not caught by reflection auto-registration ─
    // (these have no matching I*Service interface, so register explicitly — from Project B's Program.cs)
    builder.Services.AddScoped<MyDiary.Web.Features.Shared.Services.DynamicReportService>();
    builder.Services.AddScoped<MyDiary.Web.Features.Shared.Services.BreadcrumbState>();
    builder.Services.AddSingleton<MyDiary.Web.Features.Shared.Services.IInlineComponentResolver,
                                  MyDiary.Web.Features.Shared.Services.InlineComponentResolver>();
    builder.Services.AddScoped<MyDiary.Web.Features.Reports.Services.DCFEMenuReportService>();
    builder.Services.AddScoped<MyDiary.Web.Features.Reports.Services.ChequeIssuedReportService>();
    builder.Services.AddScoped<MyDiary.Web.Features.Reports.Services.SundryReportService>();
    builder.Services.AddScoped<MyDiary.Web.Features.Reports.Services.DeathClaimReportService>();
    builder.Services.AddScoped<MyDiary.Web.Features.Reports.Services.ATRReportService>();
    builder.Services.AddScoped<ChargeReportPdfService>();

    // ── Focus 360 (point at gap-sqlserver via GapReportSettings) ───────────
    builder.Services.Configure<GapReportSettings>(builder.Configuration.GetSection("Focus360"));
    builder.Services.AddScoped<IGapService, SqlGapService>();
    builder.Services.AddScoped<GapExportService>();
    // Assurance Snapshot reuses IGapService / GapReportSettings (same tables as Focus 360).
    builder.Services.AddScoped<MyDiary.Web.Features.Assurance.Services.AssuranceExportService>();
    QuestPDF.Settings.License = QuestPDF.Infrastructure.LicenseType.Community;

    // ── Hangfire (notification dispatch) — durable Oracle storage ──────────
    // Tables (HANGFIRE_*) are created under the Oracle connection's schema
    // (RP_OWNER) on first run. Queued jobs now survive app restarts.
    var hangfireCs = builder.Configuration.GetConnectionString("Oracle")
        ?? throw new InvalidOperationException("ConnectionStrings:Oracle is required for Hangfire storage.");
    var hangfireStorage = new Hangfire.Oracle.Core.OracleStorage(hangfireCs,
        new Hangfire.Oracle.Core.OracleStorageOptions
        {
            PrepareSchemaIfNecessary = true,
            QueuePollInterval        = TimeSpan.FromSeconds(15),
            InvisibilityTimeout      = TimeSpan.FromMinutes(30),
        });
    builder.Services.AddHangfire(cfg => cfg
        .SetDataCompatibilityLevel(Hangfire.CompatibilityLevel.Version_170)
        .UseSimpleAssemblyNameTypeSerializer()
        .UseRecommendedSerializerSettings()
        .UseStorage(hangfireStorage));
    builder.Services.AddHangfireServer();

    builder.Services.AddHsts(o => { o.MaxAge = TimeSpan.FromDays(365); o.IncludeSubDomains = true; });

    var app = builder.Build();

    // ── Static helpers (Project B) ──────────────────────────────────────────
    AppLogger.Initialize(app.Services);
    MyDiary.Web.Services.AdApiCrypto.CryptoServiceUrl = app.Configuration["ApiEndpoints:CryptoServiceUrl"]?.TrimEnd('/');
    MyDiary.Web.Services.AdApiCrypto.HttpClientFactory = app.Services.GetRequiredService<IHttpClientFactory>();
    MyDiary.Web.Services.AdApiCrypto.Logger = app.Services.GetRequiredService<ILoggerFactory>().CreateLogger("AdApiCrypto");

    // ── Middleware pipeline ────────────────────────────────────────────────
    if (!app.Environment.IsDevelopment())
    {
        app.UseExceptionHandler("/error");
        app.UseHsts();
    }
    else
    {
        app.UseDeveloperExceptionPage();
    }

    app.UseSerilogRequestLogging();
    app.UseHttpsRedirection();

    app.UseCookiePolicy(new CookiePolicyOptions
    {
        HttpOnly              = Microsoft.AspNetCore.CookiePolicy.HttpOnlyPolicy.Always,
        Secure                = CookieSecurePolicy.Always,
        MinimumSameSitePolicy = SameSiteMode.Strict
    });

    app.UseStaticFiles();
    app.UseRouting();

    app.UseAuthentication();
    app.UseAuthorization();
    app.UseAntiforgery();

    if (app.Environment.IsDevelopment())
        app.UseHangfireDashboard("/hangfire");

    app.Services.GetRequiredService<IRecurringJobManager>().AddOrUpdate<MyDiary.Web.Jobs.NotificationDispatchJob>(
        "md.notif.dispatch",
        j => j.RunAsync(CancellationToken.None),
        Cron.MinuteInterval(1));

    app.MapControllers();

    app.MapRazorComponents<App>()
       .AddInteractiveServerRenderMode();

    app.MapHub<MyDiary.Web.Hubs.NotificationHub>("/hubs/notifications");

    Log.Information("My Diary V3 started");
    app.Run();
}
catch (Exception ex)
{
    Log.Fatal(ex, "Application failed to start");
}
finally
{
    Log.CloseAndFlush();
}
